# lab1_neural_networks

Проект: лабораторна робота 1 — класифікація Iris за допомогою простих нейронних мереж (TensorFlow і PyTorch).

## Файли
- `tensorflow_model.py` — приклад навчання MLP на Iris з TensorFlow (tf.keras).
- `pytorch_model.py` — приклад навчання MLP на Iris з PyTorch.
- `requirements.txt` — список потрібних пакетів (версії не зафіксовані).
- `setup_git.sh` — скрипт для швидкої ініціалізації Git репозиторію і першого коміту.
- `.gitignore` — типовий .gitignore для Python-проєктів.

## Як використовувати
1. Рекомендовано створити віртуальне оточення:
   ```bash
   python -m venv venv
   source venv/bin/activate  # або venv\Scripts\activate на Windows
   pip install --upgrade pip
   pip install -r requirements.txt
   ```
2. Запуск TensorFlow прикладу:
   ```bash
   python tensorflow_model.py
   ```
3. Запуск PyTorch прикладу:
   ```bash
   python pytorch_model.py
   ```

## Git
Якщо хочете швидко створити git-репозиторій і зробити перший коміт, запустіть:
```bash
bash setup_git.sh "your_remote_url_github"
```
Перший аргумент (опційний) — URL віддаленого репозиторію. Якщо не вказано, скрипт лише ініціалізує локальний репозиторій і зробить коміт.
