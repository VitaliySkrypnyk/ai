#!/usr/bin/env bash
# Usage: ./setup_git.sh [remote_url]
set -e
git init
git add .
git commit -m "Initial commit: lab1 neural networks"
if [ ! -z "$1" ]; then
  git branch -M main
  git remote add origin "$1"
  git push -u origin main
else
  echo "No remote URL provided — local repo initialized and committed."
fi
