# tensorflow_model.py
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
import os

# Ensure plots dir exists
os.makedirs('plots', exist_ok=True)

# 1) Load data
iris = load_iris()
X = iris.data
y = iris.target

# 2) Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# 3) Scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 4) Build model (simple MLP)
model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(X_train.shape[1],)),
    tf.keras.layers.Dense(16, activation='relu'),
    tf.keras.layers.Dense(16, activation='relu'),
    tf.keras.layers.Dense(3, activation='softmax')
])

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])
model.summary()

# 5) Train
history = model.fit(X_train, y_train, epochs=60, batch_size=8, validation_split=0.1, verbose=2)

# 6) Evaluate
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
print(f"TensorFlow test accuracy: {test_acc:.4f}")

# 7) Save plots
plt.figure()
plt.plot(history.history['loss'], label='loss')
plt.plot(history.history['val_loss'], label='val_loss')
plt.title('Loss')
plt.legend()
plt.savefig('plots/tf_loss.png')

plt.figure()
plt.plot(history.history['accuracy'], label='accuracy')
plt.plot(history.history['val_accuracy'], label='val_accuracy')
plt.title('Accuracy')
plt.legend()
plt.savefig('plots/tf_accuracy.png')

# 8) Save model
model.save('tf_iris_model')
